import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:water_v0/models/challenge_provider.dart';
import 'package:water_v0/screens/neighborMap.dart';
import 'package:water_v0/screens/recompense.dart';
import 'package:water_v0/screens/recup_id_famille.dart';
import 'BottomNavigationBar.dart'; // Import du fichier
import 'facture_page.dart';
import 'Local.dart';
import 'home_screen.dart';
import 'login_screen.dart';
import 'card.dart' as FeatureCard;

class EspaceChef extends StatelessWidget {
  const EspaceChef({super.key, required this.userId, required String idUser});
  final String userId;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // En-tête avec logo
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'EcoApp',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: theme.colorScheme.primary,
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        final provider = Provider.of<ChallengeProvider>(context, listen: false);
                        provider.resetChallenges(); // Réinitialise les défis
                        await clearUserSession(); // Supprime la session utilisateur
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const LoginScreen(),
                          ),
                        );
                      },
                      child: const Text('Déconnexion'),
                    ),
                  ],
                ),

                const SizedBox(height: 30),

                // Message de bienvenue
                Text(
                  'Bonjour,',
                  style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Bienvenue dans votre\nespace Chef',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    height: 1.2,
                  ),
                ),

                const SizedBox(height: 40),

                // Bannière principale
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        theme.colorScheme.primary,
                        theme.colorScheme.secondary,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: theme.colorScheme.primary.withOpacity(0.3),
                        blurRadius: 15,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.eco_outlined,
                              color: Colors.white,
                              size: 30,
                            ),
                          ),
                          const SizedBox(width: 15),
                          const Expanded(
                            child: Text(
                              'Commencez votre parcours écologique',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 15),
                      const Text(
                        'Découvrez comment réduire votre impact environnemental au quotidien',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white,
                          height: 1.4,
                        ),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: theme.colorScheme.primary,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical: 12,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          'Commencer',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 30),

                // Titre de section
                const Text(
                  'Explorez nos fonctionnalités',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),

                const SizedBox(height: 20),

                // Grille de fonctionnalités
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 15,
                  childAspectRatio: 1.1,
                  children: [
                    FeatureCard.FeatureCard(
                      icon: Icons.star,
                      title: 'Recompenses',
                      color: theme.colorScheme.primary,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => RewardsPage(),
                          ),
                        );
                      },
                    ),
                    FeatureCard.FeatureCard(
                      icon: Icons.bar_chart_rounded,
                      title: 'Statistiques',
                      color: theme.colorScheme.secondary,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => MapUsers()),
                        );
                      },
                    ),
                    FeatureCard.FeatureCard(
                      icon: Icons.house,
                      title: 'Local',
                      color: theme.colorScheme.tertiary,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Step1Location()),
                        );
                      },
                    ),
                    FeatureCard.FeatureCard(
                      icon: Icons.receipt,
                      title: 'Facture',
                      color: Colors.amber[700]!,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => FacturePage(userId: userId)),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNavigationBar(
        currentIndex: 0,
        userId: userId,
        onTap: (index) {
          // Gérer les changements d'index si nécessaire
        },
      ),
    );
  }
}