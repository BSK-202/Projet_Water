import 'package:flutter/material.dart';
import 'package:water_v0/models/challenge_provider.dart';
import 'package:water_v0/models/challenges_screen.dart';
import 'package:water_v0/screens/home_screen.dart';
import 'package:water_v0/screens/facture_page.dart';
import 'package:water_v0/screens/profil.dart';

class CustomBottomNavigationBar extends StatelessWidget {
  final int currentIndex;
  final String userId;
  final Function(int) onTap;

  const CustomBottomNavigationBar({
    super.key,
    required this.currentIndex,
    required this.userId,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return BottomNavigationBar(
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_rounded),
          label: 'Accueil',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.emoji_events, size: 24),
          label: 'Challenge',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.badge),
          label: 'Badge',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person_outline), // Icône de facture
          label: 'Profil', // Nouveau label
        ),
      ],
      currentIndex: currentIndex,
      selectedItemColor: theme.colorScheme.primary,
      unselectedItemColor: Colors.grey,
      showUnselectedLabels: true,
      onTap: (index) {
        if (index == 0) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => const HomeScreen(),
            ),
          );
        } else if (index == 1) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ChallengesScreen(
                category: 'habits', userId: '', // ou 'sociodemographic' selon votre logique
              ),
            ),
          );
        } 
         else if (index == 3) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ProfilePage(userId: userId),
            ),
          );
        }
        onTap(index); // Appelle la fonction de rappel pour gérer les changements d'index
      },
    );
  }
}