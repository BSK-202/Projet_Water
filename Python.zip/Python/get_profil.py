from flask import Flask, request, jsonify
from db import get_connection
from flask_cors import CORS  # Ajoutez cette importation


def ischef(email):
    """Vérifie si l'utilisateur est un chef"""
    try:
        conn = get_connection()
        if not conn:
            return None
        
        cur = conn.cursor()

        # Chercher d'abord dans la table 'chef'
        cur.execute("""SELECT email FROM "chef" WHERE email = %s""", (email,))
        chef = cur.fetchone()

        if chef:  # Si l'utilisateur est un chef
            return True
        
        # Sinon vérifier dans la table membre
        cur.execute("""SELECT email FROM "Membre" WHERE email = %s""", (email,))
        membre = cur.fetchone()
        
        if membre:
            return False
        
        return None  # Utilisateur non trouvé

    except Exception as e:
        print(f"Erreur lors de l'exécution de ischef: {str(e)}")
        return None

    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals() and conn:
            conn.close()
def get_user_details(email):
    """Récupère toutes les informations utilisateur depuis la base de données"""
    try:
        conn = get_connection()
        if not conn:
            return None
        
        cur = conn.cursor()

        # Vérifier si c'est un chef ou un membre
        cur.execute("""SELECT email FROM "chef" WHERE email = %s""", (email,))
        is_chef = cur.fetchone() is not None

        # Récupérer les données de base
        if is_chef:
            cur.execute("""
                SELECT c.nom, c.prenom, c.email, c.avatar, c.score, 
                       f."nomFamille", f."scoreFamille", NULL, -- avatarFamille (NULL si chef)
                       h.duree_moyenne_douches, h.nbr_bains_par_mois,
                       h.nbr_douches_semaine, h."cosommation cuisine",
                       h.frequence_vidange_toilettes, h.frequence_lave_linge,
                       s."Revenu", s."niveau education",
                       s."Sensibilisation Environnement", s."Accès à un Plombier"
                FROM "chef" c
                LEFT JOIN "Famille" f ON c."IDfamille" = f."codeFamille"
                LEFT JOIN "Habitude" h ON c.id_habitude = h.id_habitude
                LEFT JOIN " Sociodémographique" s ON c.socio = s."idSocio"
                WHERE c.email = %s
            """, (email,))
        else:
            cur.execute("""
                SELECT m.nom, m.prenom, m.email, m.avatar, m.score, 
                       f."nomFamille", f."scoreFamille", f."avatarFamille",
                       h.duree_moyenne_douches, h.nbr_bains_par_mois,
                       h.nbr_douches_semaine, h."cosommation cuisine",
                       h.frequence_vidange_toilettes, h.frequence_lave_linge,
                       s."Revenu", s."niveau education",
                       s."Sensibilisation Environnement", s."Accès à un Plombier"
                FROM "Membre" m
                LEFT JOIN "Famille" f ON m."IDfamille" = f."codeFamille"
                LEFT JOIN "Habitude" h ON m.id_habitude = h.id_habitude
                LEFT JOIN " Sociodémographique" s ON m.socio = s."idSocio"
                WHERE m.email = %s
            """, (email,))

        user_data = cur.fetchone()
        if not user_data:
            return None

        keys = [
            'nom', 'prenom', 'email', 'avatar', 'score',
            'nomFamille', 'scoreFamille', 'avatarFamille',
            'dureeDouches', 'bainsMois', 'douchesSemaine', 'consommationCuisine',
            'freqToilettes', 'freqLaveLinge',
            'revenu', 'niveauEducation', 'sensibilisation', 'accesPlombier'
        ]
        user_dict = dict(zip(keys, user_data))
        user_dict['isChef'] = is_chef

        # Compter les champs valides dans Habitude + Socio
        habitude_fields = ['dureeDouches', 'bainsMois', 'douchesSemaine', 'consommationCuisine', 'freqToilettes', 'freqLaveLinge']
        socio_fields = ['revenu', 'niveauEducation', 'sensibilisation', 'accesPlombier']

        def count_valid(fields):
            return sum(1 for field in fields if user_dict.get(field) not in (None, 0, '0'))

        challenge_score = count_valid(habitude_fields) + count_valid(socio_fields)
        user_dict['challenge'] = challenge_score

        return user_dict

    except Exception as e:
        print(f"Erreur lors de la récupération des données utilisateur: {str(e)}")
        return None
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals() and conn:
            conn.close()



