# app.py

from flask import Flask, jsonify,request, session
from get_profil import get_user_details
from get_socio import get_socio_utilisateur
from socio import receive_sociodemographique
from get_habitude import get_habitudes_utilisateur
from habitudes import receive_habits
from classement import get_classement
from db import get_connection
from userFamily import get_family_by_member
from recompense import calculate_rewards
#****************************************************
from datetime import timedelta
from flask_cors import CORS

from registration import selection, register
from login import login
from pdf_extraction import extract_data_from_pdf
import os
from werkzeug.utils import secure_filename
from pdf_extraction import get_pdf_path_from_uploads
from flask_session import Session
from datetime import datetime, timedelta

# Connexion à PostgreSQL
conn = get_connection()
cursor = conn.cursor()
#****************************************************
app = Flask(__name__)
#****************************************************
app.config["SESSION_TYPE"] = "filesystem"
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=30)
app.secret_key = 'f095a328dd6798c545699eb4d5a79b05924717771b8558e1'
Session(app)
app.secret_key = 'f095a328dd6798c545699eb4d5a79b05924717771b8558e1'  # Clé secrète pour sécuriser les sessions

CORS(app)
@app.before_request
def make_session_permanent():
    session.permanent = True
    session.modified = True  # Set a flag indicating that the session has been modified

# Initialisation de la session serveur

#****************************************************

@app.route('/', methods=['GET'])
def classement():
    """Renvoie le classement des familles sous format JSON."""
    print("data sent")
    return jsonify(get_classement())



# Route API pour obtenir la famille d'un utilisateur par son ID
@app.route('/get_family/<string:member_id>', methods=['GET'])
def get_family(member_id):
    family = get_family_by_member(member_id)
    if family:
        print("family sent")
        return jsonify({"status": "success", "family": family}), 200
    else:
        return jsonify({"status": "error", "message": "Famille non trouvée"}), 404


#****************************************************
@app.route('/selection', methods=['POST'])
def handle_selection():
    data = request.get_json()
    return selection(data)

@app.route('/register', methods=['POST'])
def handle_register():
    data = request.get_json()
    return register(data)

@app.route('/login', methods=['POST'])
def login_route():
    """Route pour gérer la demande de connexion"""
    data = request.get_json()
    data_user=login(data)
    session["user_id"] =  data_user["user_id"]# chef[2] est l'email (index 2)
    session["is_chef"] = data_user["is_chef"]  # # chef[3] est le mot de passe (index 3)
    session["id_famille"] =data_user["idFamille"] 
    session.modified = True 
    return data_user







# Assurez-vous que le dossier upload existe
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['ALLOWED_EXTENSIONS'] = {'pdf'}

# Fonction pour vérifier l'extension du fichier
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Fonction pour supprimer tous les fichiers dans le dossier 'uploads'
def clear_upload_folder():
    for filename in os.listdir(UPLOAD_FOLDER):
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)  # Supprime le fichier
            elif os.path.isdir(file_path):
                os.rmdir(file_path)  # Supprime le répertoire s'il est vide
        except Exception as e:
            print(f"Erreur lors de la suppression du fichier {file_path}: {e}")

@app.route('/extract_pdf', methods=['POST'])
def extract_pdf():
    if 'file' not in request.files:
        return jsonify({"message": "Aucun fichier sélectionné"}), 400
    user_id = request.form.get('user_id')  # Récupération du user_id

    print(user_id)
    file = request.files['file']
    
    if file and allowed_file(file.filename):
         # Avant de sauvegarder le fichier, nettoyer le répertoire d'upload
        #clear_upload_folder()

        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        pdf_path = get_pdf_path_from_uploads()  # Récupérer le chemin du fichier PDF depuis le dossier "uploads"

        # Vous pouvez maintenant appeler la fonction d'extraction du PDF ici
        result = extract_data_from_pdf(pdf_path,user_id)
        print(result)
        return result
    

@app.route('/factures', methods=['GET'])
def get_factures():
    conn = None
    cur = None
    try:
        # Connexion à la base de données
        conn = get_connection()
        if not conn:
            return jsonify({"message": "❌ Connexion à la base échouée"}), 500

        cur = conn.cursor()
        user_id = request.args.get('user_id')
        # Vérifier si user_id est présent
        if not user_id:
            return jsonify({"message": "❌ Paramètre user_id manquant"}), 400

        cur.execute("""
            SELECT "dateFacture", "coutConsommation" 
            FROM "Facture" 
            WHERE "IDfamilleRefFact" = %s;
        """, (user_id,))

        factures = cur.fetchall()
        factures_list = [
            {"dateFacture": row[0].strftime("%Y-%m-%d"),  # Formatage de la date
             "consommation_eau_m3": float(row[1])}  # Conversion en float
            for row in factures
        ]

        return jsonify(factures_list)
    
    except Exception as e:
        print(f"🔥 Erreur: {str(e)}")  # Log pour débogage
        return jsonify({"message": f"❌ Erreur serveur: {str(e)}"}), 500

    finally:
        # Fermeture sécurisée des ressources
        if cur:
            cur.close()
        if conn:
            conn.close()



###########################local

@app.route('/adresse', methods=['POST'])
def ajouter_adresse():
    try:
        data = request.json
        ville = data.get("ville")
        quartier = data.get("quartier")
        region = data.get("region")
        latitude = data.get("latitude")
        longitude = data.get("longitude")

        cursor.execute(
            'INSERT INTO "Adresse" (ville, quartier, region, localisation) '
            'VALUES (%s, %s, %s, point(%s, %s)) '
            'RETURNING adresse',
            (ville, quartier, region, longitude, latitude)
        )
        
        adresse_id = cursor.fetchone()[0]
        conn.commit()

        return jsonify({
            "status": "success",
            "message": "Adresse ajoutée avec succès",
            "adresse_id": adresse_id
        }), 200

    except Exception as e:
        conn.rollback()
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/local', methods=['POST'])
def ajouter_local():
    try:
        data = request.json
        
      

        # Insertion du nouveau local
        cursor.execute(
            'INSERT INTO "Local" '
            '(type, surface, "nbChambre", "nbDouche", "nbVoiture", '
            '"nbCuisine", piscine, garage, jardin, "codeFamille", adress, nb_personne) '
            'VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) '
            'RETURNING "IDlocal"',
            (data["type"], data["surface"], data["nbChambre"], 
             data["nbDouche"], data["nbVoiture"], data["nbCuisine"],
             data["piscine"], data["garage"], data["jardin"],
             data["codeFamille"], data["adress"], data["nb_personne"])
        )
        
        local_id = cursor.fetchone()[0]
        conn.commit()

        return jsonify({
            "status": "success",
            "message": "Local enregistré avec succès",
            "local_id": local_id
        }), 200

    except Exception as e:
        conn.rollback()
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
    


  
@app.route('/calculate_rewards', methods=['GET'])
def calculate_rewards_endpoint():
    family_code = request.args.get('user')
    if not family_code:
        return jsonify({"error": "Le code famille est requis."}), 400

    result = calculate_rewards(family_code)
    if not result:
        return jsonify({"error": "Famille non trouvée ou données insuffisantes."}), 404

    return jsonify(result)

@app.route('/habits', methods=['POST'])
def receive_habits_main():
    try:
        # Récupérer les données JSON envoyées par l'application Flutter
        data = request.get_json()
       
        # Afficher les données dans la console
        print("Données reçues :")
        print(f"ID: {data.get('id')}")
        print(f"Category: {data.get('category')}")
        print(f"Value: {data.get('value')}")
        print(f"Points: {data.get('points')}")
        print(f"User ID: {data.get('user_id')}")

        # Retourner une réponse de succès
        return receive_habits(data)

    except Exception as e:
        # Gérer les erreurs et retourner une réponse d'erreur
        print(f"Erreur lors de la réception des données : {str(e)}")
        return jsonify({"error": "Erreur lors de la réception des données"}), 500
    
@app.route('/get_completed_habits', methods=['POST'])
def get_completed_habits():
    try:
        data = request.get_json()
        if not data or 'user_id' not in data:
            print("Erreur : User ID manquant")
            return jsonify({"error": "User ID requis"}), 400

        user_id = data.get('user_id')
        print(f"User ID reçu : {user_id}")

        # Appeler la fonction pour récupérer les habitudes
        return get_habitudes_utilisateur({"user_id": user_id})
    except Exception as e:
        print(f"Erreur : {str(e)}")
        return jsonify({"error": "Erreur lors de la récupération des habitudes"}), 500
    #*********************************
@app.route('/socio', methods=['POST'])
def get_socio():
    try:
        print("hhhhh")
        data = request.get_json()
        print(data)
        if not data or 'user_id' not in data:
            print("Erreur : User ID manquant")
            return jsonify({"error": "User ID requis"}), 400

        user_id = data.get('user_id')
        print(f"User ID reçu : {user_id}")

        # Appeler la fonction pour récupérer les habitudes
        return receive_sociodemographique(data)
    except Exception as e:
        print(f"Erreur : {str(e)}")
        return jsonify({"error": "Erreur lors de la récupération des habitudes"}), 500
    #**********
    
@app.route('/get_socio', methods=['POST'])
def get_socio_rec():
    try:
        print("hoho")
        data = request.get_json()
        
        if not data or 'user_id' not in data:
            print("Erreur : User ID manquant")
            return jsonify({"error": "User ID requis"}), 400

        user_id = data.get('user_id')
        print(f"***********************//User ID reçu socio : {user_id}")

        # Appeler la fonction pour récupérer les habitudes
        return get_socio_utilisateur(data)
    except Exception as e:
        print(f"Erreur : {str(e)}")
        return jsonify({"error": "Erreur lors de la récupération des socio hhh"}), 500
    #**********
    
@app.route('/profile', methods=['GET'])
def get_user_profile():
        email = request.args.get('email')
        if not email:
            return jsonify({'error': 'Email parameter is required'}), 400

        user_data = get_user_details(email)
        if not user_data:
            return jsonify({'error': 'User not found'}), 404

        return jsonify(user_data)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
